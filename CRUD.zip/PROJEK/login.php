<?php
session_start();
$errorMessage = '';
$servername = "localhost";
$dbUsername = "root"; // Ganti sesuai username database Anda
$dbPassword = ""; // Ganti sesuai password database Anda
$dbname = "layanan";

// Buat koneksi
$conn = new mysqli($servername, $dbUsername, $dbPassword, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Memproses login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Mengambil data pengguna dari database
    $stmt = $conn->prepare("SELECT password, role FROM tb_user WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $errorMessage = 'Akun belum ada, silakan buat akun terlebih dahulu.';
    } else {
        $row = $result->fetch_assoc();

        // Membandingkan password langsung tanpa hash
        if ($password == $row['password']) {
            // Simpan username dan role dalam session
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $row['role']; // Simpan role pengguna

            // Arahkan berdasarkan role
            if ($row['role'] == 'admin') {
                header('Location: admin_dashboard.php'); // Halaman khusus admin
            } else {
                header('Location: dashboard.php'); // Halaman untuk user biasa
            }
            exit();
        } else {
            $errorMessage = 'Username atau password salah!';
        }
    }
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title>Login</title>
</head>
<body>
    <div class="container">
        <div class="image-side"></div>
        <div class="form-side">
            <div class="form-box">
                <div class="login-box">
                    <h2>Welcome</h2>

                    <!-- Tampilkan alert jika ada pesan error -->
                    <?php if ($errorMessage): ?>
                        <script>
                            alert('<?php echo $errorMessage; ?>');
                        </script>
                    <?php endif; ?>

                    <form action="login.php" method="POST">
                        <div class="input-box">
                            <label for="username">Username</label>
                            <input type="text" id="username" name="username" required>
                        </div>
                        <div class="input-box">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        <div class="options">
                            <label><input type="checkbox" name="remember"> Remember Me</label>
                            <a href="#">Forgot Password?</a>
                        </div>
                        <button type="submit">Log In</button>
                    </form>
                    <p>Don't have an account? <a href="register.php">Register</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
